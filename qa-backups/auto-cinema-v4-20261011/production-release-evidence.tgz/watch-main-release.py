import subprocess,json,time,pathlib,os,sys,datetime
root=pathlib.Path('/workspace/kamen-v4-recovery'); run='38112449790'; expected='5ea7d953f1720654521a2cd9d800706d40f40c49'; start=time.monotonic();last=None;failures=0
while True:
 try:
  d=json.loads(subprocess.check_output(['gh','api',f'repos/jankendo/JIZURA_KAMEN/actions/runs/{run}'],stderr=subprocess.PIPE));assert d['head_sha']==expected
  failures=0;state=(d['status'],d['conclusion']);(root/'main-ci-monitor.json').write_text(json.dumps({'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run':run,'head':expected,'status':d['status'],'conclusion':d['conclusion']},indent=2)+'\n')
  if state!=last:print('Main CI:',state,flush=True);last=state
  if d['status']=='completed':
   assert d['conclusion']=='success',d['conclusion'];break
 except subprocess.CalledProcessError as e:
  failures+=1;print('Main CI connection check failed',failures,flush=True)
  if failures>=3:raise
 assert time.monotonic()-start<145*60,'Main CI monitor deadline reached'
 for n in range(6):
  time.sleep(50)
  print('Waiting main CI; approved source and rollback point preserved.',flush=True)
subprocess.run([sys.executable,str(root/'capture-ci.py'),run,expected,str(root/'release-main-ci')],check=True,stdout=(root/'release-main-ci-summary.txt').open('w'))
s=json.loads((root/'release-main-ci/summary.json').read_text());assert all(j['conclusion']=='success' for j in s['jobs']);assert any(j['name']=='deploy' for j in s['jobs'])
print('Main build and Pages deploy SUCCESS; verifying published HTTPS file hashes.',flush=True)
subprocess.run([sys.executable,str(root/'verify-production-files.py'),expected,str(root/'release-production-https')],check=True)
print('Published file hashes PASS; starting actual production browser and MP4 E2E.',flush=True)
env=os.environ.copy();env['KAMEN_CHROME']='/usr/bin/chromium'
with (root/'release-production-e2e.console.txt').open('w') as f:
 p=subprocess.run(['npm','run','test:cinema-export','--','https://jankendo.github.io/JIZURA_KAMEN/',str(root/'release-production')],cwd='/workspace/kamen-cinema-v4-release',env=env,stdout=f,stderr=subprocess.STDOUT)
print('Production E2E exit:',p.returncode,flush=True)
assert p.returncode==0,'Inspect release-production-e2e.console.txt'
print('PRODUCTION_PIPELINE_PASS; raw MP4 and browser report saved.',flush=True)
