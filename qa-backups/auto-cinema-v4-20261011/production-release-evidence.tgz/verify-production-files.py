import pathlib,json,hashlib,urllib.request,urllib.parse,sys,datetime
manifest=pathlib.Path('/workspace/kamen-v4-recovery/evidence/docs/qa/auto-cinema-v4/release-20261011/build-manifest.json')
d=json.loads(manifest.read_text()); commit=sys.argv[1]; out=pathlib.Path(sys.argv[2]); out.mkdir(parents=True,exist_ok=True); rows=[]
for f in d['files']:
 url='https://jankendo.github.io/JIZURA_KAMEN/'+urllib.parse.quote(f['path'])+'?kamen_release='+commit
 with urllib.request.urlopen(urllib.request.Request(url,headers={'Cache-Control':'no-cache'}),timeout=60) as response:
  data=response.read(); row={'path':f['path'],'http':response.status,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'expectedSHA256':f['sha256']}
 row['match']=row['sha256']==f['sha256'] and row['bytes']==f['bytes'];rows.append(row)
 (out/f['path']).parent.mkdir(parents=True,exist_ok=True);(out/f['path']).write_bytes(data)
r={'sourceHEAD':d['sourceHEAD'],'mainMergeSHA':commit,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS' if all(x['match'] for x in rows) else 'FAIL','files':rows}
(out/'https-build-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'verifiedFiles':len(rows)}));sys.exit(0 if r['status']=='PASS' else 1)
