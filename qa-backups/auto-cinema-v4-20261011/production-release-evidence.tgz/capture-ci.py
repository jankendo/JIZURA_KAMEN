import subprocess,json,pathlib,sys
run=sys.argv[1];expected=sys.argv[2];out=pathlib.Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
def api(path):return json.loads(subprocess.check_output(['gh','api',path]))
base='repos/jankendo/JIZURA_KAMEN/actions/runs/'+run
r=api(base);jobs=api(base+'/jobs');artifacts=api(base+'/artifacts')
assert r['head_sha']==expected,(r['head_sha'],expected)
for name,data in [('run',r),('jobs',jobs),('artifacts',artifacts)]: (out/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n')
summary={'run':run,'head':r['head_sha'],'event':r['event'],'status':r['status'],'conclusion':r['conclusion'],'jobs':[{'name':j['name'],'conclusion':j['conclusion'],'steps':[{'name':s['name'],'conclusion':s['conclusion']} for s in j['steps']]} for j in jobs['jobs']]}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
if r['status']=='completed':
 with (out/'console.txt').open('w') as f: subprocess.run(['gh','run','view',run,'--repo','jankendo/JIZURA_KAMEN','--log'],stdout=f,check=True)
