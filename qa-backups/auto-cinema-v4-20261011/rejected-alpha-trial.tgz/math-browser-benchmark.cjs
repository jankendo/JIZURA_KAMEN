'use strict';
const fs=require('fs'),{chromium}=require('/workspace/JIZURA_KAMEN/node_modules/playwright-core');
const extract=p=>{const s=fs.readFileSync(p,'utf8');return s.slice(s.indexOf('const stencils='),s.indexOf('J.measureAudioEndpointSeam='));};
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});try{const page=await browser.newPage();await page.goto('http://127.0.0.1:4180/');await page.waitForFunction(()=>window.J?.cinemaV3);const out=await page.evaluate(async({oldSource,newSource})=>{
 await J.ensureFonts('光へ向かう Hello 世界',['embedded_bold']);
 const make=source=>new Function('J','const C=J.clamp;\n'+source+'\nreturn J.decodedGlyphContrast;')({clamp:J.clamp}),old=make(oldSource),current=make(newSource),w=384,h=216,canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;const ctx=canvas.getContext('2d'),masks=[];
 for(let k=0;k<20;k++){ctx.clearRect(0,0,w,h);ctx.font='700 32px "JIZURA Noto CJK JP"';ctx.fillText('光へ向かう Hello 世界',10+k,50+k);masks.push(J.cinemaPrimaryAlpha(ctx.getImageData(0,0,w,h).data));}
 const actual=Array(w*h).fill(.9),background=Array(w*h).fill(.2),rounds=[];
 for(const mode of ['same-alpha-classes','alternate-two-masks','twenty-masks']){
  const maskAt=i=>masks[mode==='same-alpha-classes'?0:mode==='alternate-two-masks'?i%2:i%20];
  for(let i=0;i<30;i++){const a=old(actual,background,maskAt(i),w,h),b=current(actual,background,maskAt(i),w,h);if(JSON.stringify(a)!==JSON.stringify(b))throw Error('Math observer differs');}
  for(let trial=0;trial<6;trial++){const times={};for(const key of trial%2?['current','old']:['old','current']){const fn=key==='old'?old:current,start=performance.now();for(let i=0;i<60;i++)fn(actual,background,maskAt(i),w,h);times[key]=performance.now()-start;}rounds.push({mode,trial,iterations:60,...times});}
 }
 return {status:'PASS_EXACT_DIFFERENTIAL',scope:'Browser math microbenchmark, not end-to-end performance acceptance',browser:navigator.userAgent,dimensions:[w,h],rounds};
 },{oldSource:extract('/workspace/kamen-v4-recovery/saved-v4/src/11zzy_closed_loop.js'),newSource:extract('/workspace/JIZURA_KAMEN/src/11zzy_closed_loop.js')});fs.writeFileSync('/workspace/kamen-v4-recovery/math-browser-benchmark.json',JSON.stringify(out,null,2));console.log(JSON.stringify(out));}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1});
