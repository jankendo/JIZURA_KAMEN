import json,hashlib,gzip,pathlib,statistics,sys,datetime
folder=pathlib.Path(sys.argv[1]); out=pathlib.Path(sys.argv[2]); out.mkdir(parents=True,exist_ok=True)
raw=json.loads((folder/'results.json').read_text()); rows=raw['rows']; expected=int(sys.argv[4]) if len(sys.argv)>4 else 126; aliases={'baseline':'main','pr5':sys.argv[5] if len(sys.argv)>5 else 'PR8','v3':'V4'}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stats(vals):
 vals=sorted(v for v in vals if isinstance(v,(float,int)))
 return {'n':len(vals),'p50':statistics.median(vals),'p95':vals[__import__('math').ceil(len(vals)*.95)-1],'maximum':max(vals)} if vals else {'n':0,'status':'UNMEASURED'}
def cohort(r):
 i=r['fixture']['id'];return 'repeat' if i.startswith('repeat-') else 'additional' if i.startswith('general-') else 'independent' if i.startswith('independent-') else 'original'
def series(r):
 hist=[{'line':line['line'],'time':s['time'],'score':(s.get('contrast') or {}).get('score'),'actualTime':None} for line in (((r.get('decoded') or {}).get('layerPresence') or {}).get('primaryText') or {}).get('samples',[]) for s in line['samples']]
 a=r.get('independentlyAlignedReadability') or {}
 return {'historical':hist,'aligned':a.get('samples',[]),'backgroundConsistent':(a.get('backgroundConsistentReadability') or {}).get('samples',[])}
def compare(before,after):
 valid=before['status']==after['status']=='PASS';matching=valid and before.get('input')==after.get('input') and before.get('sourceInvariant')==after.get('sourceInvariant')
 result={'id':before['fixture']['id'],'baseline':aliases[before['variant']],'status':'COMPARABLE' if matching else 'INCOMPARABLE_INPUT_OR_FAILURE','sameInputAndProfile':matching,'intervals':{},'globalRegression':False}
 if not matching:return result
 a=(before.get('decoded') or {}).get('metrics',{}).get('localContrast');b=(after.get('decoded') or {}).get('metrics',{}).get('localContrast');result.update(before=a,after=b,globalRegression=isinstance(a,(int,float)) and isinstance(b,(int,float)) and b<a)
 for key,ss in series(before).items():
  other={(s.get('line'),round(s['time'],7)):s for s in series(after)[key]};loss=[];missing=[];measured=0
  for s in ss:
   t=other.get((s.get('line'),round(s['time'],7)));x=s.get('score',(s.get('contrast') or {}).get('score'));y=t.get('score',(t.get('contrast') or {}).get('score')) if t else None
   if t is None or s.get('actualTime')!=t.get('actualTime') or not isinstance(x,(int,float)) or not isinstance(y,(int,float)):missing.append({'line':s.get('line'),'time':s['time'],'reason':'CLOCK_OR_SAMPLE_MISSING_OR_UNMEASURED'});continue
   measured+=1
   if y<x:loss.append({'line':s.get('line'),'time':s['time'],'actualTime':s.get('actualTime'),'before':x,'after':y})
  result['intervals'][key]={'measured':measured,'incomparableOrUnmeasured':missing,'regressions':loss}
 return result
pairs=[]
for i in sorted(set(r['fixture']['id'] for r in rows)):
 group={r['variant']:r for r in rows if r['fixture']['id']==i}
 if 'v3' in group:
  for key in ['baseline','pr5']:
   if key in group:pairs.append(compare(group[key],group['v3']))
performance={}
for c in ['original','additional','independent','repeat','unique-materials']:
 performance[c]={}
 for v,label in aliases.items():
  rs=[r for r in rows if r['status']=='PASS' and r['variant']==v and (cohort(r)==c if c!='unique-materials' else cohort(r)!='repeat')]
  performance[c][label]={k:stats([r['timing'][k] for r in rs]) for k in ['totalMs','searchMs','exportMs']}
  performance[c][label]['slowest']=[{'id':r['fixture']['id'],'totalMs':r['timing']['totalMs']} for r in sorted(rs,key=lambda r:r['timing']['totalMs'],reverse=True)[:3]]
compact=[]
for r in rows:
 compact.append({'id':r['fixture']['id'],'fixture':r['fixture'],'cohort':cohort(r),'variant':aliases[r['variant']],'status':r['status'],'runtimeHTMLSHA256':r.get('runtimeHTMLSHA256'),'inputHash':hashlib.sha256(json.dumps({'input':r.get('input'),'sourceInvariant':r.get('sourceInvariant')},sort_keys=True).encode()).hexdigest(),'sourceInvariant':r.get('sourceInvariant'),'videoHash':r.get('sha256'),'planHash':(r.get('provenance',{}).get('cinemaV3') or {}).get('planHash',r.get('provenance',{}).get('planHash')),'certificationPassed':r.get('validation',{}).get('certification',{}).get('passed'),'codecs':[s['codec_name'] for s in r.get('ffprobe',{}).get('streams',[])],'localContrast':(r.get('decoded') or {}).get('metrics',{}).get('localContrast'),'decodedMetrics':(r.get('decoded') or {}).get('metrics'),'intervals':series(r),'timing':r.get('timing'),'profile':r.get('profile'),'nativeOperations':r.get('readabilityOperations'),'stencilOperations':r.get('stencilOperations'),'sameBlobScores':[x.get('score') for x in r.get('sameVideoObserverRepeats',[])],'error':r.get('error'),'resourceFailures':r.get('resources'),'failedVideo':r.get('failedVideo')})
manifest=[{'file':p.name,'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(folder.glob('*.mp4'))]
summary={'capturedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'COMPLETE' if len(rows)==expected and all(r['status']=='PASS' for r in rows) else 'INCOMPLETE_OR_FAILED','sourceHEAD':sys.argv[3] if len(sys.argv)>3 else 'UNBOUND','environment':raw['environment'],'expectedRows':expected,'actualRows':len(rows),'passed':sum(r['status']=='PASS' for r in rows),'failed':sum(r['status']=='FAIL' for r in rows),'notRun':expected-len(rows),'historicalEvidence':{'preservedUnchanged':True,'passed':66,'failed':5,'notRun':55,'originalRawVideoAvailability':'NOT_RECOVERED','comparability':'INCOMPARABLE_BROWSER_VERSION: historical Chromium 154 vs current Chromium 151; no pooled statistics'},'quality':{label:{'measured':len(a:=[(r.get('decoded') or {}).get('metrics',{}).get('localContrast') for r in rows if r['variant']==v and r['status']=='PASS' and isinstance((r.get('decoded') or {}).get('metrics',{}).get('localContrast'),(int,float))]),'median':statistics.median(a) if a else None} for v,label in aliases.items()},'performance':performance,'comparisons':pairs,'qualityRegressions':[p for p in pairs if p.get('globalRegression') or any(x['regressions'] for x in p['intervals'].values())],'inputOrFailureComparisonGaps':[p for p in pairs if p['status']!='COMPARABLE'],'timingMethod':raw['method'],'timingLimits':'Shared host; inclusive nested function times must not be summed; later same-Blob observation, FFmpeg and persistence excluded. One trial per unique input; repeats separately reported. No significance claim.','humanEvaluation':'HUMAN_EVALUATION_PENDING','peakProcessGpuMemory':'UNMEASURED','releaseDecision':'NO-GO_PENDING_FINAL_CI_AND_ALL_GATES','raw':{'path':str(folder/'results.json'),'bytes':(folder/'results.json').stat().st_size,'sha256':digest(folder/'results.json')},'videoManifest':manifest}
(out/'continuation-summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
(out/'continuation-observations.json.gz').write_bytes(gzip.compress(json.dumps(compact,separators=(',',':'),ensure_ascii=False).encode(),mtime=0))
print(json.dumps({k:summary[k] for k in ['status','actualRows','passed','failed','notRun','quality']}))
