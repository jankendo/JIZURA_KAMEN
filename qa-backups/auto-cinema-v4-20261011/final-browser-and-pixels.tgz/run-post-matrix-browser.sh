#!/usr/bin/env bash
set -euo pipefail
cd /workspace/JIZURA_KAMEN
ready=false
for attempt in {1..1800}; do
 if test -f /workspace/kamen-v4-recovery/matrix-exit.json; then ready=true; break; fi
 sleep 5
done
if test "$ready" != true; then echo 'BLOCKED: matrix completion marker missing'; exit 2; fi
python - <<'PY'
import json,sys
sys.exit(json.load(open('/workspace/kamen-v4-recovery/matrix-exit.json'))['exitCode'])
PY
export KAMEN_QA_URL=http://127.0.0.1:4180/
export JIZURA_VARIABLE_FONT=/workspace/kamen-migration/qa/NotoSansJP-variable.ttf
node dev/browser_export_e2e.cjs /usr/bin/chromium /workspace/kamen-v4-recovery/browser/saved-project.json /workspace/kamen-v4-recovery/browser/audio.wav /workspace/kamen-v4-recovery/final-browser-font FinalChromium full > /workspace/kamen-v4-recovery/final-browser-font.log 2>&1
export JIZURA_BROWSER_QA_REPORT=/workspace/kamen-v4-recovery/final-browser-font/FinalChromium-full-report.json
node dev/variable_font_browser_test.js > /workspace/kamen-v4-recovery/variable-font-regression.log 2>&1
node dev/browser_export_e2e_test.js > /workspace/kamen-v4-recovery/browser-export-regression.log 2>&1
python - <<'PY'
import json,pathlib,hashlib,datetime
p=pathlib.Path('/workspace/kamen-v4-recovery');font=pathlib.Path('/workspace/kamen-migration/qa/NotoSansJP-variable.ttf')
(p/'final-browser-font/identity.json').write_text(json.dumps({'sourceHEAD':'49660a766dbbf003b5c46cf7922aada34a3e79fd','runtimeHTMLSHA256':hashlib.sha256((p/'final-candidate/dist/index.html').read_bytes()).hexdigest(),'variableFontSHA256':hashlib.sha256(font.read_bytes()).hexdigest(),'endedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'twoPreviouslySkippedRegressions':'PASS_WITH_REAL_BROWSER_REPORT','timingPurpose':'NOT_A_PERFORMANCE_BENCHMARK'},indent=2))
PY
