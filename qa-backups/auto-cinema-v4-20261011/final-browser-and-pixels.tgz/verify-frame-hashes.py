import pathlib,json,subprocess
r=pathlib.Path('/workspace/kamen-v4-recovery');p=r/'visual-review/complete-frame-comparison.json';data=json.loads(p.read_text())
for row in data['rows']:
 arrays=[]
 for variant in ['pr5','v3']:
  dest=r/f'visual-review/{row["id"]}-{variant}.framehash.txt'
  subprocess.run(['ffmpeg','-v','error','-nostdin','-threads','1','-i',str(r/f'final-matrix/{row["id"]}-{variant}.mp4'),'-map','0:v:0','-c:v','rawvideo','-threads','1','-f','framehash','-hash','sha256',str(dest)],check=True,timeout=180)
  arrays.append([s.strip() for s in dest.read_text().splitlines() if s and not s.startswith('#')])
 row['perFrameSHA256Equal']=bool(arrays[0]) and arrays[0]==arrays[1];row['frameHashCounts']=[len(s) for s in arrays];row['status']='PASS_EXACT_DECODED_PIXELS' if row['perFrameSHA256Equal'] else 'DIFFERENT_PIXELS_OR_TIMESTAMPS';print(row['id'],row['status'],flush=True)
data['method']='Full-resolution decoded frame SHA256 including frame timestamps, durations and sizes, for both complete videos. SSIM is an auxiliary rounded diagnostic; exact equality is established by every frame SHA256, not rounded SSIM.';data['status']='PASS' if len(data['rows'])==42 and all(a['perFrameSHA256Equal'] for a in data['rows']) else 'DIFFERENCES_OR_FAILURE';p.write_text(json.dumps(data,indent=2)+'\n')
