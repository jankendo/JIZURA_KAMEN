import pathlib,json,zipfile,subprocess,hashlib
from PIL import Image,ImageDraw
qa=pathlib.Path('/workspace/kamen-next-evidence/docs/qa/generalization');out=pathlib.Path('/workspace/kamen-unit-control/actual-decoded-visual-review');out.mkdir(exist_ok=True);tmp=pathlib.Path('/tmp/kamen-target-visual');tmp.mkdir(exist_ok=True);manifest=[]
for case,aid in [('development-06',12011121026),('holdout-10',12011495200)]:
 z=zipfile.ZipFile('/tmp/artifact-'+str(aid)+'.zip');r=json.loads(z.read('effect-counterfactual-report.json'));profile=r['outputProfile'];start=profile['range'][0];fps=profile['fps'];c=r['spec']['targetCut'];native=[f['time'] for f in r['clips'][0]['nativeFrames']];requested=[c['start']-1/fps,c['start'],c['start']+1/fps,(c['start']+c['end']-c.get('outDur',0))/2];indices=[max(0,min(len(native)-1,min(range(len(native)),key=lambda i:abs(native[i]-t)))) for t in requested];w,h=profile['resolution'];thumbw=360;thumbh=round(h*thumbw/w);sheet=Image.new('RGB',(thumbw*3,(thumbh+24)*4),'#151515');draw=ImageDraw.Draw(sheet)
 paths={'ORIGINAL':qa/'media'/(r['originalVideoSHA256']+'.mp4')}
 for mode in ['ON','OFF']:paths[mode]=pathlib.Path('/tmp/kamen-target-pixel-analysis')/(case+'-'+mode+'.mp4')
 for col,(mode,path) in enumerate(paths.items()):
  clocks=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_frames','-show_entries','frame=best_effort_timestamp_time','-of','json',str(path)]))['frames']
  for row,i in enumerate(indices):
   png=tmp/(case+'-'+mode+'-'+str(i)+'.png');subprocess.run(['ffmpeg','-v','error','-i',str(path),'-vf','select=eq(n\\,'+str(i)+')','-frames:v','1','-y',str(png)],check=True);actual=start+float(clocks[i]['best_effort_timestamp_time']);image=Image.open(png);image.resize((thumbw,thumbh)).save(tmp/'view.png');sheet.paste(image.resize((thumbw,thumbh)),(col*thumbw,row*(thumbh+24)+24));draw.text((col*thumbw+3,row*(thumbh+24)+3),mode+' PTS '+str(round(actual,6)),fill='white');manifest.append({'fixture':case,'mode':mode,'frameIndex':i,'requestedSourceTime':requested[row],'actualDecodedSourceTime':actual,'actualNativeSourceTime':native[i],'videoSHA256':hashlib.sha256(path.read_bytes()).hexdigest(),'PNG_SHA256':hashlib.sha256(png.read_bytes()).hexdigest()})
   if mode=='ORIGINAL' and row==3:Image.open(png).save(out/(case+'-original-hold.png'))
 sheet.save(out/(case+'-controls.png'))
(out/'manifest.json').write_text(json.dumps({'method':'Four contract anchors: one output frame before source-cut start, nearest start, one frame after start, hold midpoint. Every displayed image is a real FFmpeg-decoded MP4 frame; Native times retained separately. No aesthetic or whole-film verdict.','frames':manifest},indent=2)+'\n');print('24 actual decoded images extracted')
