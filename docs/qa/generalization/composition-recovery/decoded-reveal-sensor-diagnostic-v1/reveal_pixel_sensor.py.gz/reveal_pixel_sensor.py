"""Selected-unit image contribution in decoded pixels; no aesthetic grading."""
import numpy as np
PIXEL_FLOOR=1.;RELATIVE_ERROR=.1;MIN_AGREEMENT=.9;MIN_FRAMES=3;MIN_GROWTH=.02

def luma(rgb):return np.asarray(rgb,dtype=np.float64)[...,:3]@np.array([.2126,.7152,.0722])
def blocks(mask):
 h,w=mask.shape;ph=(-h)%16;pw=(-w)%16;p=np.pad(mask,((0,ph),(0,pw)));grid=p.reshape((h+ph)//16,16,(w+pw)//16,16).any(axis=(1,3));return np.repeat(np.repeat(grid,16,axis=0),16,axis=1)[:h,:w]
def measure(native_on,native_off,decoded_original,decoded_on,decoded_off,decoded_repeat):
 arrays=[np.asarray(x) for x in [native_on,native_off,decoded_original,decoded_on,decoded_off,decoded_repeat]]
 assert len({x.shape for x in arrays})==1 and arrays[0].ndim==4,'DIFFERENT_IMAGE_POPULATIONS'
 no,nf,orig,on,off,repeat=map(luma,arrays);expected=no-nf;observed=orig-off;control=on-off;noise=np.abs(on-repeat);masks=np.abs(expected)>PIXEL_FLOOR;areas=masks.sum(axis=(1,2));positive=np.where(areas>0)[0]
 if len(positive)<MIN_FRAMES:return {'status':'UNMEASURED','reason':'FEWER_THAN_THREE_POSITIVE_NATIVE_FRAMES','positiveNativeFrames':len(positive),'nativeAreas':areas.tolist()}
 first=positive[0];peak=int(np.argmax(areas));growth=1-areas[first]/areas[peak];native_peak_mass=float(np.abs(expected[peak])[masks[peak]].sum())
 if growth<=MIN_GROWTH:return {'status':'UNMEASURED','reason':'NO_RESOLVED_NATIVE_REVEAL_GROWTH','nativeGrowth':float(growth),'nativeAreas':areas.tolist()}
 union_footprint=blocks(masks.any(axis=0));rows=[];measured=[]
 for i in range(len(areas)):
  n=expected[i];o=observed[i];c=control[i];mask=masks[i];tol=np.maximum.reduce([np.full_like(n,PIXEL_FLOOR),RELATIVE_ERROR*np.abs(n),3*noise[i]]);floor=np.maximum(0,MIN_AGREEMENT*np.abs(n)-PIXEL_FLOOR)
  matched=mask&(n*o>0)&(np.abs(n-o)<=tol)&(np.abs(o)>=floor);control_matched=mask&(n*c>0)&(np.abs(n-c)<=tol)&(np.abs(c)>=floor);area=int(matched.sum());measured.append(area);coverage=area/int(areas[i]) if areas[i] else None;control_coverage=int(control_matched.sum())/int(areas[i]) if areas[i] else None
  significant=np.abs(o)>np.maximum(PIXEL_FLOOR,3*noise[i]);mass=np.abs(o)*significant;total=float(mass.sum());footprint=blocks(mask) if areas[i] else union_footprint;owned=float(mass[footprint].sum())/total if total else 1.;extra=float(mass[(~mask)&union_footprint].sum())/native_peak_mass if native_peak_mass else None
  rows.append({'frameIndex':i,'nativeArea':int(areas[i]),'observedRegisteredArea':area,'registeredAgreement':coverage,'controlRegisteredAgreement':control_coverage,'ownedDifferenceMassFraction':owned,'extraDifferenceMassFractionOfNativePeak':extra,'originalVsONNoiseRMS':float(np.sqrt(np.mean((orig[i]-on[i])**2))),'repeatNoiseRMS':float(np.sqrt(np.mean(noise[i]**2)))})
 observed_growth=1-measured[first]/measured[peak] if measured[peak] else None;realization=observed_growth/growth if observed_growth is not None else None
 if any(r['controlRegisteredAgreement'] is not None and r['controlRegisteredAgreement']<MIN_AGREEMENT for r in rows):state,reason='CONFOUNDED','CONTROL_REENCODE_TARGET_NOT_STABLE'
 elif any(r['ownedDifferenceMassFraction']<MIN_AGREEMENT for r in rows):state,reason='CONFOUNDED','UNRELATED_DECODED_CHANGE_NOT_ISOLATED'
 elif any(r['extraDifferenceMassFractionOfNativePeak']>RELATIVE_ERROR for r in rows):state,reason='FAILED','PREMATURE_OR_UNEXPECTED_TARGET_INK'
 elif any(r['registeredAgreement'] is not None and r['registeredAgreement']<MIN_AGREEMENT for r in rows):state,reason='FAILED','EXPECTED_VISIBLE_TARGET_MISSING_OR_DIFFERENT_AT_ACTUAL_FRAME'
 elif realization is None or realization<MIN_AGREEMENT:state,reason='FAILED','DECODED_REVEAL_GROWTH_NOT_REALIZED'
 else:state,reason='VERIFIED','REGISTERED_TARGET_REVEAL_AND_ACTUAL_FRAME_TIMING_MATCH'
 return {'status':state,'reason':reason,'nativeGrowth':float(growth),'observedGrowth':observed_growth,'realization':realization,'firstPositiveFrame':int(first),'nativePeakFrame':peak,'positiveNativeFrames':len(positive),'frames':rows,'scope':'Physical selected-unit appearance/area/timing only; original glyph/source safety and artistic quality remain separate.'}
