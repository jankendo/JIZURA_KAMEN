import pathlib,subprocess,json,hashlib,numpy as np
from PIL import Image,ImageDraw,ImageFont
from reveal_pixel_sensor import measure
out=pathlib.Path('/workspace/kamen-unit-control/sensor-calibration');out.mkdir(exist_ok=True);h,w=180,320;N=9;font=ImageFont.truetype('/workspace/kamen-next/assets/fonts/NotoSansCJKjp-Bold.ttf',32);base=np.zeros((h,w,3),np.uint8);base[:]=[18,37,55];glyph=Image.new('RGBA',(w,h),(0,0,0,0));ImageDraw.Draw(glyph).text((55,65),'KAMEN 光',font=font,fill=(255,255,255,255));rgba=np.asarray(glyph);alpha=rgba[...,3].astype(float)/255;progress=np.array([0,.15,.3,.5,.7,.85,1,1,1]);
def images(prog,previous=False):
 a=np.repeat(base[None],len(prog),axis=0)
 if previous:
  for i in range(len(a)):a[i,72:90,20:85]=[180,180,180]
 for i,q in enumerate(prog):
  clip=np.zeros((h,w),bool);clip[:,55:55+int(220*q)]=True;coverage=alpha*clip;a[i]=np.rint(a[i]*(1-coverage[...,None])+255*coverage[...,None]).astype(np.uint8)
 return a

def encode(a,name):
 p=out/(name+'.mp4');cmd=['ffmpeg','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{w}x{h}','-r','24','-i','-','-f','lavfi','-i','anullsrc=r=48000:cl=stereo','-t',str(len(a)/24),'-c:v','libx264','-preset','fast','-qp','18','-pix_fmt','yuv420p','-c:a','aac','-shortest','-y',str(p)];subprocess.run(cmd,input=a.tobytes(),check=True);subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(p),'-f','null','-'],check=True);b=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-map','0:v:0','-pix_fmt','rgb24','-f','rawvideo','-']);d=np.frombuffer(b,np.uint8).reshape(-1,h,w,3);assert len(d)==len(a);return d
normal=images(progress);off=np.repeat(base[None],N,axis=0);dn=encode(normal,'normal');df=encode(off,'off');results=[]
cases=[('correct_progressive_wipe',normal,off,dn,{'VERIFIED'}),('whole_character_steps',images(np.array([0,.2,.2,.4,.4,.7,1,1,1])),off,None,{'VERIFIED'}),('unchanged_hold',images(np.ones(N)),off,None,{'UNMEASURED'}),('opposite_reveal',normal,off,encode(images(progress[::-1]),'opposite'),{'FAILED','CONFOUNDED'}),('delayed_onset',normal,off,encode(images(np.r_[0,0,progress[:-2]]),'delayed'),{'FAILED','CONFOUNDED'}),('different_unit',normal,off,encode(np.roll(normal,95,axis=2),'wrong-unit'),{'FAILED','CONFOUNDED'}),('background_flicker',normal,off,encode(np.minimum(normal.astype(int)+np.arange(N)[:,None,None,None]*4,255).astype(np.uint8),'flicker'),{'FAILED','CONFOUNDED'}),('undersampled',normal[:2],off[:2],dn[:2],{'UNMEASURED'}),('overlapping_previous_unit',images(progress,True),images(np.zeros(N),True),None,{'VERIFIED'})]
faint=np.repeat(base[None],N,axis=0).copy();faint=np.rint(faint*.99+images(np.ones(N))*.01).astype(np.uint8);cases.append(('faint_full_unit_prematurely_visible',normal,off,encode(faint,'faint-premature'),{'FAILED','CONFOUNDED'}))
extra=normal.copy();extra[:,135:168,265:300]=255;cases.append(('unrelated_extra_layer',normal,off,encode(extra,'extra-layer'),{'FAILED','CONFOUNDED'}))
tiny=np.repeat(base[None],N,axis=0);tinyfull=tiny.copy();tinyfull[:,67:76,50:59]=255
for i,q in enumerate(progress):tiny[i,67:76,50:50+int(9*q)]=255
cases.append(('premature_unit_inside_same_macroblock',tiny,off,encode(tinyfull,'tiny-premature'),{'FAILED','CONFOUNDED'}))
for name,no,nf,actual,allowed in cases:
 a=actual if actual is not None else encode(no,name+'-on');f=df[:len(no)] if np.array_equal(nf,off[:len(no)]) else encode(nf,name+'-off');reference=dn[:len(no)] if np.array_equal(no,normal[:len(no)]) else encode(no,name+'-reference');np.savez_compressed(out/(name+'-native-truth.npz'),ON=no,OFF=nf);result=measure(no,nf,a,reference,f,reference);results.append({'case':name,'expected':sorted(allowed),'actual':result['status'],'PASS':result['status'] in allowed,'measurement':result});print(name,result['status'],result.get('reason'),flush=True)
report={'nativeSource':'Alpha-only glyph paint preserves the previous overlapping unit; trial01 opaque stripe prototype retained separately.', 'scope':'Independent synthetic native truth with actual H264/AAC encodes and complete decode; no actual target frames used','cases':results,'pass':sum(r['PASS'] for r in results),'fail':sum(not r['PASS'] for r in results)};(out/'counterexamples.json').write_text(json.dumps(report,indent=2)+'\n');print('TOTAL',report['pass'],report['fail']);assert report['fail']==0
